#!/bin/sh
#/usr/local/etc/init.d/avahi start
modprobe ipv6
export LD_LIBRARY_PATH=/usr/ifi/ifi-tidal/Tidal-Connect-Armv7/lib

/home/tc/Tidal-Connect-Armv7/bin/tidal_connect --tc-certificate-path /home/tc/Tidal-Connect-Armv7/id_certificate/IfiAudio_ZenStream.dat -f TidalConnectPiCore --playback-device default --disable-web-security false --disable-app-security false --enable-websocket-log 0
