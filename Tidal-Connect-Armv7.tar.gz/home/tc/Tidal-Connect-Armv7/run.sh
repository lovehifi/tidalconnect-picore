#!/bin/sh

#touch /var/run/dbus/pid
/usr/local/etc/init.d/avahi start